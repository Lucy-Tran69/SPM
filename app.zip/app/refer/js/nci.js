$(function () {
   pagename = $("#page-name").val();
   if (pagename){
       $("#d-page-name").text(pagename);
   }
});